var wizard_model = {
  confirmed: {
    SLat: "0",
    SLng: "1",
    DLat: "2",
    DLng: "3",
    CAT: "4",
    TXT: "",
    font_size: 30,
    smartLabel: true
  },

}
