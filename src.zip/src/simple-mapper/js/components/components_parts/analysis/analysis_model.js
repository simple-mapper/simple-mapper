var analysis_model = {
  init: {
    gradient_column: "null",
    gradient_x_small_color: "#FFFACD",
    gradient_small_color: "#FFD700",
    gradient_medium_color: "#FF8C00",
    gradient_large_color: "#FF0000",
    gradient_x_small_size: 5,
    gradient_small_size: 10,
    gradient_medium_size: 20,
    gradient_large_size: 30,
  }
}
