var plugins_model = {
  confirmed: [
  //   {
  //   name: "office365",
  //   fun: office365.gen,
  //   div: "office365_plugins_div"
  // },
  {
    name: "scheduler",
    fun: scheduler.gen,
    div: "scheduler_plugins_div"
  }],
}
