var office365_config = {

  gen: function(){

  },

  init: function(text){

  },

  render: function(text){

  },

  post_render: function(){
    document.getElementById("office365_test").addEventListener('click', office365_api.getData, false);

  },

}
