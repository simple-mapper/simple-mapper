window.onload = function() {
  rate_viewer_main.gen();
}
