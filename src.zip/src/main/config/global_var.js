var __dirname = '.'
